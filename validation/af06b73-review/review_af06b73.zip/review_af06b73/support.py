"""Read-only independent checks of Git-blob-verified CliPP1.5 reviewed sources.

Actual driver/trace/staging functions are executed after AST extraction to avoid
importing a whole unmounted repository. CUDA, policy plumbing, and the input
reader are explicitly controlled doubles. These are NOT CUDA qualification,
full repository tests, cohort execution, or a production-parser integration test.
"""
from __future__ import annotations
import ast,argparse,hashlib,io,json,sys,tempfile,traceback,zipfile
from collections import deque
from contextlib import contextmanager,redirect_stdout
from dataclasses import dataclass,asdict
from pathlib import Path
from time import perf_counter
from types import SimpleNamespace as NS
import numpy as np
import torch
ROOT=Path(__file__).resolve().parent
COMMIT='af06b7305b1928aeeabeac5ab5c5b454d2369c3f'
BLOBS={'qualify_surrogate_cuda.py':'08ff98842b4b4d835e238f008787a499c026cd50',
       'surrogate_trace.py':'015f22f44d8b21aa80d42a1c493dc13325fe4345',
       'cohort_staging.py':'9d0f293165c3514b1586ed24865a8ce3e5e73fe0'}
C='scalar_backtracking_v1';E='coordinate_backtracking_v1'
def require(ok,msg):
    if not ok:raise AssertionError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def tsha(t):return hashlib.sha256(t.detach().cpu().numpy().tobytes()).hexdigest()
def clean(x):
    if isinstance(x,float) and not np.isfinite(x):return None
    if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [clean(v) for v in x]
    return x
def write(p,x):
    with Path(p).open('x') as f:json.dump(clean(x),f,indent=2,allow_nan=False)
def load(p):return json.loads(Path(p).read_text())
@dataclass(frozen=True)
class Policy:
    inner_atol:float=1e-10
    inner_rtol:float=1e-11
    inner_kkt_tol:float=1e-7
class Journal:
    """Controlled journal with the real duplicate-artifact guard and bind semantics."""
    def __init__(self,p):
        self.receipt_path=Path(p);self.root=self.receipt_path.with_name(self.receipt_path.stem+'.artifacts')
        self.path=self.receipt_path.with_name(self.receipt_path.stem+'.events.jsonl')
        self.root.mkdir(parents=True);self.path.touch();self.artifacts={}
    def artifact(self,name,value):
        p=self.root/name;rel=str(p.relative_to(self.receipt_path.parent))
        require(rel not in self.artifacts,'Qualification artifact must not be overwritten')
        write(p,value);self.artifacts[rel]=sha(p);return rel
    def bind(self,p):self.artifacts[str(Path(p).relative_to(self.receipt_path.parent))]=sha(p)
class SignalStub:
    SIGALRM=14;SIGTERM=15
    def __init__(self):self.initial={14:object(),15:object()};self.handlers=self.initial.copy();self.alarms=[]
    def signal(self,s,v):old=self.handlers[s];self.handlers[s]=v;return old
    def alarm(self,s):self.alarms.append(s)
def extracted(name,ns):
    p=ROOT/'sources'/name;b=p.read_bytes();got=hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
    assert got==BLOBS[name]
    tree=ast.parse(b);nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
    exec(compile(ast.Module(nodes,type_ignores=[]),str(p),'exec'),ns)
    return ns
common=NS(sha=sha,tensor_sha=tsha,write_json=write,utc_now=lambda:'2026-09-23T00:00:00Z')
def diag(f,p):return dict(inner_qp_qualified=bool(f and f.qualified),mock_plumbing=True)
def tracing_ns():return extracted('surrogate_trace.py',dict(deque=deque,np=np,torch=torch,common=common,inner_certificate_diagnostics=diag))
def driver():
    signal=SignalStub();tr=tracing_ns();mixed=NS(require=require,load_json=load,Journal=Journal,SCHEMA='mock',
        fixtures=NS(FAMILIES=('mixed_support','below_one'),SIZES=(64,256,512),RECIPE='mock'),
        source_provenance=lambda:dict(source_sha256='source'),check_predecessor=lambda *a:None,helper_hashes=lambda:{'mock':1})
    ns=dict(argparse=argparse,contextmanager=contextmanager,asdict=asdict,json=json,Path=Path,signal=signal,
        sys=sys,perf_counter=perf_counter,traceback=traceback,np=np,
        torch=NS(__version__='MOCK CUDA environment; no GPU used',version=NS(cuda=None),cuda=NS(get_device_name=lambda d:'MOCK')),
        common=common,mixed=mixed,tracing=NS(**tr),CudaPolicy=Policy,SCHEMA='clipp1d.cuda.surrogate_experiment.v2',
        CONTROL=C,CANDIDATE=E,ORIGINAL_HELPERS=lambda:{},__doc__='Review',
        source_provenance=lambda:dict(source_sha256='source'),require_cuda=lambda d:d)
    extracted('qualify_surrogate_cuda.py',ns)
    ns['helpers']=lambda:{'mock':1};ns['load_predecessor']=lambda *a:None
    return ns,signal

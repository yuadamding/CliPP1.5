"""Independent control-flow checks of Git-blob-verified af06b73 source.

CUDA inference, signal delivery, policies, and surrounding repository services
are controlled doubles. Real function bodies are AST-loaded from verified files.
No archived CUDA fits or whole-repository test suite are run by this script.
"""
from __future__ import annotations
import ast, hashlib, importlib.util, json, tempfile
from pathlib import Path
from statistics import median
from types import SimpleNamespace as NS
import numpy as np
import torch

ROOT=Path(__file__).resolve().parent
BLOBS={
    'qualify_surrogate_cuda.py':'e5b74bc39f110bdd4a2f53015f901a9d0ee3d3d4',
    'surrogate_trace.py':'015f22f44d8b21aa80d42a1c493dc13325fe4345',
    'time_surrogate_cuda.py':'9deaf11310adbd92f48477a9df54c5e2dc1e8979',
}
# Reuse only the controlled dependency plumbing from the prior review, not its assertions.
spec=importlib.util.spec_from_file_location('review_support',ROOT/'support.py')
old=importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name]=old
spec.loader.exec_module(old)
old.ROOT=ROOT;old.BLOBS.update(BLOBS)

def timing(ns):
    path=ROOT/'sources/time_surrogate_cuda.py'
    tree=ast.parse(path.read_bytes())
    study=NS(CONTROL=old.C,CANDIDATE=old.E,SCHEMA=ns['SCHEMA'],StartLog=ns['StartLog'],
             CudaPolicy=old.Policy,strategy=ns['strategy'],helpers=ns['helpers'])
    d=dict(study=study, common=old.common, mixed=ns['mixed'],np=np,torch=torch,median=median,
           asdict=old.asdict,Path=Path,perf_counter=old.perf_counter,traceback=old.traceback)
    exec(compile(ast.Module([v for v in tree.body if isinstance(v,(ast.FunctionDef,ast.ClassDef))],type_ignores=[]),str(path),'exec'),d)
    return d

def main():
    verified={}
    for name,digest in BLOBS.items():
        b=(ROOT/'sources'/name).read_bytes()
        actual=hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
        assert actual==digest
        verified[name]={'git_blob_sha1':actual,'sha256':hashlib.sha256(b).hexdigest()}
    results={}
    t=lambda a:torch.tensor(a,dtype=torch.float64)
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp)
        for mode in ('solver_exception','dispatch_exception','returned_unqualified'):
            ns,_=old.driver();count=[0]
            def solve(*a,**k):
                count[0]+=1
                if count[0]==1 and mode=='solver_exception':raise RuntimeError('injected solver failure')
                policy='wrong' if count[0]==1 and mode=='dispatch_exception' else old.E
                return NS(qualified=not(count[0]==1 and mode=='returned_unqualified'),
                          diagnostics=dict(outer_surrogate_policy=policy,status='controlled'))
            ns['solver']=NS(solve_start=solve)
            original_source=ns['mixed'].source_provenance
            j=old.Journal(root/(mode+'.json'))
            caught=[]
            with ns['strategy'](old.E,j) as calls:
                for lam in (1.,2.):
                    try:ns['solver'].solve_start(None,None,t(lam),None,old.Policy())
                    except (RuntimeError,AssertionError) as error:caught.append(type(error).__name__)
                counts=calls.counts()
            assert ns['solver'].solve_start is solve and ns['mixed'].source_provenance is original_source
            names=sorted(p.name for p in j.root.glob('*surrogate-trace.json'))
            assert names==['start-000-surrogate-trace.json','start-001-surrogate-trace.json']
            assert [a['index'] for a in calls.attempts]==[0,1]
            assert counts['starts_attempted']==2 and counts['starts_qualified']==1
            assert counts['starts_returned']==(1 if mode=='solver_exception' else 2)
            assert counts['starts_raised']==(0 if mode=='returned_unqualified' else 1)
            results[mode]={'passed':True,'counts':counts,'trace_files':names}
        # Timing boundary with actual wrapper and controlled CUDA-clock substitute.
        ns,_=old.driver();seen=[]
        def solve(*a,**k):
            assert 'observer' not in k
            seen.append('solve')
            return NS(qualified=True,diagnostics=dict(outer_surrogate_policy=old.E,status='qualified'))
        ns['solver']=NS(solve_start=solve)
        timing_ns=timing(ns)
        def timed(device,function):
            seen.append('start-sync-stub');v=function();seen.append('stop-sync-stub');return v,3.
        timing_ns['common']=NS(timed=timed)
        def fit(model):
            ns['solver'].solve_start(None,None,t(1.),None,old.Policy());return 'fit-result'
        timing_ns['selection']=NS(fit_tensor_model=fit)
        value,seconds,calls=timing_ns['timed_fit'](None,old.E,'mock-device')
        assert (value,seconds)==('fit-result',3.) and seen==['start-sync-stub','solve','stop-sync-stub']
        assert calls.counts()['starts_qualified']==1
        results['timing_boundary']={'passed':True,'sequence':seen,'actual_cuda':False}
        def row(warmup,complete,ratio):
            return dict(warmup=warmup,complete_pair=complete,speedup_control_over_candidate=ratio,
                        candidate_seconds=3.,control_seconds=6.)
        rows=[row(True,True,100.),row(False,False,None),row(False,True,2.)]
        r=timing_ns['summarize'](rows)
        assert r['complete_warm_pairs']==1 and r['median_paired_speedup']==2.
        assert timing_ns['summarize'](rows[:2])['median_paired_speedup'] is None
        assert timing_ns['order'](0)==timing_ns['order'](2)==tuple(reversed(timing_ns['order'](1)))
        results['cold_and_incomplete_exclusion']={'passed':True,'result':r}
        # An incomplete control must not acquire a throughput ratio.
        def trial(lam,complete):
            return dict(repeat=1,warmup=False,fit_seconds=2.,publication_qualified=complete,
                        summary=dict(selected_lambda=lam,raw_objective=1.+.6*lam,cluster_labels=[0,1],
                        refitted_ccf=[.3,.7],score=2.,search_status='complete' if complete else 'incomplete',
                        pilot_and_graph={key:'same' for key in ('pilot_sha256','weights_sha256','weight_rule','gap_floor','normalization')}))
        for same in (True,False):
            r=timing_ns['compare'](trial(1. if same else 2.,True),trial(1.,False))
            assert r['speedup_control_over_candidate'] is None and not r['complete_pair']
            assert (r['raw_objective_difference'] is None)==(not same)
        results['timing_comparison_gates']={'passed':True,'scenarios':2}
        # Recompute statistics from the three published pairs; no timing executed.
        published=[(15.702466500923038,15.91534615890123),
                   (15.637660942971706,15.937826458131894),
                   (15.715834759175777,15.837806958938017)]
        pairs=[dict(warmup=False,complete_pair=True,candidate_seconds=a,control_seconds=b,
                    speedup_control_over_candidate=b/a) for a,b in published]
        recomputed=timing_ns['summarize'](pairs)
        assert recomputed['median_paired_speedup']==1.0135570840393564
        results['published_timing_arithmetic']={'passed':True,'source':'below64-b.json comparisons, values copied from pinned GitHub receipt',
                                              'summary':recomputed,'raw_pairs_candidate_control_seconds':published,
                                              'median_latency_reduction_fraction':1-recomputed['candidate_median_seconds']/recomputed['control_median_seconds']}
    result=dict(commit='af06b7305b1928aeeabeac5ab5c5b454d2369c3f',
                scope='Control-flow checks of verified function bodies using explicitly controlled dependencies; receipt arithmetic only',
                environment=dict(python=sys.version,torch=torch.__version__,cuda_available=torch.cuda.is_available()),
                not_run=['whole repository suite','CUDA inference or kernel compilation','LSF queries','binary archive verifier','captured rational proof'],
                source_hashes=verified,checks=results)
    (ROOT/'independent_checks.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v['passed'] for k,v in results.items()},indent=2))
if __name__=='__main__':main()

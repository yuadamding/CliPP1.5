"""Verify a stopped predecessor and reuse only its independently valid fits."""
import os
from pathlib import Path
from common import digest,read,write,now


def prepare_recovery(root,p):
    audit=read(root/'parent-audit.json')
    old=Path(p['predecessor_root'])
    assert str(old)==audit['root'] and old.resolve()==old and old.stat().st_uid==os.getuid()
    assert digest(old/'PREPARED.json')==audit['plan_sha256']
    assert digest(old/'receipts/controller-terminal.json')==audit['terminal_sha256']
    owner=read(old/'receipts/controller-process.json')['identity']
    assert owner==audit['owner'] and owner['host']==os.uname().nodename
    proc=Path('/proc')/str(owner['pid'])/'stat'
    if proc.exists():
        fields=proc.read_text().rsplit(')',1)[1].split()
        assert fields[19]!=owner['start_ticks'] or fields[0]=='Z','Predecessor still alive'
    terminal=read(old/'receipts/controller-terminal.json')
    assert not terminal['active'] and not terminal['unknown_submissions']
    prior=read(old/'PREPARED.json')
    for key in ('source_sha256','cuda_policy','python','environment_sha256','compiler','max_major_cn',
                'clonal_constraint','clonal_label_rule','max_submitted','gpu_request','payload_sha256'):
        assert p[key]==prior[key],key
    found=set()
    for folder in (old/'receipts').iterdir():
        if not folder.is_dir() or not (folder/'submit-intent.json').exists():
            continue
        key=folder.name;found.add(key)
        bound=audit['receipts'][key]
        assert digest(folder/'accepted.json')==bound['accepted_sha256']
        assert digest(folder/'reconciled.json')==bound['reconciled_sha256']
        rec=read(folder/'reconciled.json')
        assert rec['accepted']==read(folder/'accepted.json') and rec['scheduler_state'] in ('DONE','EXIT')
    assert found==set(audit['receipts'])
    cases={c['key']:c for c in read(root/'cases.json')}
    old_cases={c['key']:c for c in read(old/'cases.json')}
    assert cases.keys()==old_cases.keys()
    for key,case in cases.items():
        assert {k:v for k,v in case.items() if k!='input_filename'}==old_cases[key]
    from worker import validate
    imports={};outcomes={}
    for item in p['imports']:
        key=item['key'];assert key not in imports and item in audit['imports']
        assert item['root']==str(old)
        case=cases[key]
        assert item['input_sha256']==case['input_sha256'] and item['truth_sha256']==case['truth_sha256']
        rec=read(old/'receipts'/key/'reconciled.json');outcome=rec['outcome']
        assert digest(old/'receipts'/key/'reconciled.json')==item['reconciled_sha256']
        assert outcome['status']==item['status'] and outcome['status'].startswith('validated_')
        task=old/'results'/key
        assert digest(task/'validated.json')==item['validated_sha256']==outcome['validated_sha256']
        v=read(task/'validated.json')
        assert v['output_sha256']==item['output_sha256']
        verified=validate(root,case,task/'output')
        assert verified=={k:v[k] for k in ('metrics','output_sha256','source_sha256','search_status')}
        imports[key]=dict(item,metrics=v['metrics'])
        outcomes[key]=outcome['status']
    assert len(imports)==len(audit['imports'])==p['imported_cases']
    write(root/'receipts/imports-validated.json',dict(imports=imports,utc=now(),
          parent_audit_sha256=digest(root/'parent-audit.json'),predecessor_stopped=True))
    return outcomes

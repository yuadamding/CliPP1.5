"""Aggregate validated outcomes; finished quick cases remain a selected subset."""
from collections import Counter, defaultdict
from pathlib import Path
import sys
import numpy as np
from common import digest, read, write


def ccc(x,y):
    x,y=np.asarray(x,dtype=float),np.asarray(y,dtype=float)
    if not len(x):
        return None
    if np.ptp(x)==0 or np.ptp(y)==0:
        return float(np.array_equal(x,y))
    return float(2*np.mean((x-x.mean())*(y-y.mean()))/(np.var(x)+np.var(y)+(x.mean()-y.mean())**2))


def summarize(root):
    cohorts=defaultdict(list)
    imports=read(root/"receipts/imports-validated.json")["imports"]
    for case in read(root/'cases.json'):
        folder=root/'receipts'/case['key']
        record=folder/'reconciled.json'
        outcome=read(record)['outcome'] if record.exists() else dict(status='unfinished')
        metric=None
        if case['key'] in imports:
            item=imports[case['key']]
            assert not record.exists(),'Imported case was submitted again'
            outcome=dict(status=item['status'],validated_sha256=item['validated_sha256'])
        if outcome['status'].startswith('validated_'):
            result_root=Path(imports[case['key']]['root']) if case['key'] in imports else root
            result=result_root/'results'/case['key']/'validated.json'
            assert digest(result)==outcome['validated_sha256']
            metric=read(result)['metrics']
        cohorts[case['dataset']].append((outcome['status'],metric))
    result={}
    for dataset,rows in cohorts.items():
        metrics=[m for _,m in rows if m is not None]
        multi=[m['ari'] for m in metrics if not m['true_k_one']]
        pooled=defaultdict(Counter)
        for m in metrics:
            for label,counts in m['cna_only_multiplicity']['per_class'].items():
                pooled[label].update({k:counts[k] for k in ('tp','fp','fn','support')})
        eligible=sum(m['cna_only_multiplicity']['eligible'] for m in metrics)
        called=sum(m['cna_only_multiplicity']['called'] for m in metrics)
        for counts in pooled.values():
            d=2*counts['tp']+counts['fp']+counts['fn']
            counts['f1']=2*counts['tp']/d if d else 0.0
        tp,fp,fn=(sum(c[k] for c in pooled.values()) for k in ('tp','fp','fn'))
        result[dataset]=dict(planned=len(rows),outcome_counts=dict(Counter(s for s,_ in rows)),
            validated=len(metrics),imported=sum(c['dataset']==dataset and c['key'] in imports for c in read(root/'cases.json')),ari_mean=float(np.mean([m['ari'] for m in metrics])) if metrics else None,
            multi_cluster_ari_mean=float(np.mean(multi)) if multi else None,
            true_k_one=sum(m['true_k_one'] for m in metrics),
            true_k_one_false_splits=sum(m['true_k_one'] and m['selected_k']>1 for m in metrics),
            ccf_rmse_mean=float(np.mean([m['rmse'] for m in metrics])) if metrics else None,
            smf_ccc=ccc([m['true_smf'] for m in metrics],[m['estimated_smf'] for m in metrics]),
            cna_only_multiplicity=dict(eligible=eligible,called=called,coverage=called/eligible if eligible else None,
                macro_f1=float(np.mean([c['f1'] for c in pooled.values()])) if pooled else None,
                micro_f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else None,
                weighted_f1=sum(c['f1']*c['support'] for c in pooled.values())/eligible if eligible else None,
                per_class=dict(pooled)))
    return dict(cohorts=result,scope='validated final-refit outputs; incomplete searches counted separately; partial cohorts are size-biased',
                ccc_convention='identical constants=1; other constant-vector cases=0')


if __name__=='__main__':
    root=Path(sys.argv[1])
    write(root/'results/summary.json',summarize(root))

import hashlib
import json
from pathlib import Path
import sys

import pytest

sys.path.insert(0,str(Path(__file__).resolve().parent))
import controller as c
import worker as w
from common import digest, read, write


def base(tmp_path):
    (tmp_path/'receipts').mkdir()
    (tmp_path/'lsf-logs').mkdir()
    write(tmp_path/'PREPARED.json',{'source_sha256':'source','cuda_policy':{}})
    return tmp_path


def test_ambiguous_submission_is_never_repeated(tmp_path,monkeypatch):
    root=base(tmp_path)
    calls=[]
    def uncertain(argv, timeout):
        calls.append(argv)
        return dict(code=None,stdout='Job <123> is submitted to queue <egpu>.',stderr='lost connection')
    monkeypatch.setattr(c,'command',uncertain)
    p=dict(queue_hard_minutes=360,python='/python')
    case=dict(key='000001',memory_gb=8,wall_minutes=60)
    with pytest.raises(AssertionError,match='Ambiguous'):
        c.submit(root,case,p)
    assert read(root/'receipts/000001/accepted.json')['job_id']=='123'
    with pytest.raises(FileExistsError):
        c.submit(root,case,p)
    assert len(calls)==1


def test_unknown_retains_slot(tmp_path,monkeypatch):
    root=base(tmp_path)
    a=dict(key='000001',job_id='123',job_name='mine')
    monkeypatch.setattr(c,'command',lambda *args:dict(code=255,stdout='',stderr='unavailable'))
    states,done=c.reconcile(root,{'123':a})
    assert states=={'123':'UNKNOWN'} and not done


def test_foreign_scheduler_identity_rejected(tmp_path,monkeypatch):
    root=base(tmp_path)
    a=dict(key='000001',job_id='123',job_name='mine')
    monkeypatch.setattr(c,'command',lambda *args:dict(code=0,stdout='123 someone DONE mine',stderr=''))
    with pytest.raises(AssertionError,match='Foreign'):
        c.reconcile(root,{'123':a})


def test_scheduler_log_requires_matching_job_and_user(tmp_path):
    root=base(tmp_path)
    a=dict(key='000001',job_id='123',job_name='mine')
    f=root/'lsf-logs/000001.123.out'
    raw='Subject: Job 123: <mine>\nJob <mine> was submitted from host <x> by user <yding4>\nResults reported at x\nTerminated at x\nSuccessfully completed.\n'
    f.write_text(raw)
    assert c.log_proof(root,a)['state']=='DONE'
    f.write_text(raw.replace('yding4','foreign'))
    assert c.log_proof(root,a) is None


def test_foreign_worker_cannot_write_terminal(tmp_path,monkeypatch):
    root=base(tmp_path)
    monkeypatch.setattr(w,'plan',lambda root:dict(python=sys.executable))
    def reject(root,key):
        raise AssertionError('foreign owner')
    monkeypatch.setattr(w,'accepted',reject)
    with pytest.raises(AssertionError,match='foreign owner'):
        w.worker(root,'000001')
    assert not list((root/'receipts').rglob('terminal.json'))


def outputs(tmp_path,complete):
    root=base(tmp_path)
    tree=root/'source/benchmarks'
    tree.mkdir(parents=True)
    actual=Path(__file__).resolve().parents[2]/'benchmarks/compare_clipp2.py'
    (tree/'compare_clipp2.py').write_bytes(actual.read_bytes())
    task=root/'results/000001'
    output=task/'output'
    output.mkdir(parents=True)
    truth=task/'truth.tsv'
    truth.write_text('mutation_id\ttrue_ccf\ttrue_cluster\tmajor_cn\tminor_cn\ttrue_multiplicity\na\t1\t0\t2\t1\t2\nb\t0.5\t1\t2\t1\t1\n')
    (output/'mutation_clusters.tsv').write_text('tumor_id\tsample_id\tmutation_id\tstatus\trefitted_ccf\tcluster_label\tdesignated_clonal\nt\ts\ta\tretained\t1\t0\t1\nt\ts\tb\tretained\t0.5\t1\t0\n')
    (output/'cluster_centers.tsv').write_text('cluster_label\tcluster_size\trefitted_ccf\tdesignated_clonal\n0\t1\t1\t1\n1\t1\t0.5\t0\n')
    (output/'mutation_multiplicity.tsv').write_text('mutation_id\traw_multiplicity_call\trefitted_multiplicity_call\na\t1\t2\nb\t2\t1\n')
    run=dict(schema='clipp1d.cuda.run.v3',status='success',provenance=dict(source_sha256='source',input_sha256='input',backend='cuda',dtype='float64',
        clonal_constraint=False,clonal_label_rule='nearest_to_one_l2_v1',policy={},max_major_cn=4,compiled_inference=True,cpu_numeric_fallback=False),
        candidate_provenance=dict(raw_qualified=True,refit_qualified=True,candidate_family='complete_graph_path',graph_sha256='graph',raw_certificate={}),
        graph_sha256='graph',raw_diagnostics={},search_status='complete' if complete else 'incomplete',selected_lambda=1,selection_score=2,
        search=[dict(raw_status='qualified',refit_status='qualified',search_complete=complete,score=2,clusters=2,lambda_value=1)],
        table_sha256={f.name:digest(f) for f in output.iterdir()})
    write(output/'run.json',run)
    case=dict(input_sha256='input',retained_mutations=2,retained_ids_sha256=hashlib.sha256(json.dumps(['a','b']).encode()).hexdigest(),
              tumor_id='t',sample_id='s',truth_sha256=digest(truth),truth_coverage=1.0,truth_unmatched_retained=[])
    return root,case,output


@pytest.mark.parametrize('complete',[True,False])
def test_serialized_metrics_use_refit_calls_and_preserve_incompleteness(tmp_path,complete):
    root,case,output=outputs(tmp_path,complete)
    v=w.validate(root,case,output)
    assert v['metrics']['cna_only_multiplicity']['macro_f1']==1
    assert v['metrics']['ari']==1 and v['metrics']['true_smf']==v['metrics']['estimated_smf']==.5
    assert v['search_status']==('complete' if complete else 'incomplete')


def test_table_tampering_rejected(tmp_path):
    root,case,output=outputs(tmp_path,True)
    with (output/'mutation_clusters.tsv').open('a') as out:
        out.write('tampered\n')
    with pytest.raises(AssertionError):
        w.validate(root,case,output)


def test_partial_reconciliation_reuses_completed_terminal_receipt(tmp_path,monkeypatch):
    root=base(tmp_path)
    a=dict(key='000001',job_id='123',job_name='mine')
    folder=root/'receipts/000001'
    folder.mkdir()
    outcome=dict(job_id='123',key='000001',status='scientific_failure')
    write(folder/'reconciled.json',dict(accepted=a,scheduler_state='DONE',outcome=outcome))
    monkeypatch.setattr(c,'command',lambda *args:dict(code=0,stdout='123 yding4 DONE mine',stderr=''))
    states,done=c.reconcile(root,{'123':a})
    assert states=={'123':'DONE'} and done==[('123',outcome)]



def import_fixture(tmp_path,monkeypatch):
    import recovery
    old=tmp_path/'old';old.mkdir();base(old)
    new=tmp_path/'new';new.mkdir();base(new)
    policy={k:None for k in ('python','environment_sha256','compiler','max_major_cn',
        'clonal_constraint','clonal_label_rule','max_submitted','gpu_request','payload_sha256')}
    policy.update(source_sha256='source',cuda_policy={})
    write(old/'PREPARED.json',policy,replace=True)
    write(new/'PREPARED.json',policy,replace=True)
    owner=dict(pid=999999999,start_ticks='0',host=c.os.uname().nodename)
    write(old/'receipts/controller-process.json',dict(identity=owner))
    write(old/'receipts/controller-terminal.json',dict(active={},unknown_submissions=[]))
    case=dict(key='000001',input_sha256='input',truth_sha256='truth',dataset='test')
    write(old/'cases.json',[case]);write(new/'cases.json',[dict(case,input_filename='original.tsv')])
    task=old/'results/000001';task.mkdir(parents=True)
    value=dict(source_sha256='source',output_sha256={},metrics={'ari':1},search_status='complete')
    write(task/'validated.json',value)
    folder=old/'receipts/000001';folder.mkdir()
    a=dict(job_id='123',key='000001')
    write(folder/'submit-intent.json',{})
    write(folder/'accepted.json',a)
    outcome=dict(status='validated_complete',validated_sha256=digest(task/'validated.json'))
    write(folder/'reconciled.json',dict(accepted=a,scheduler_state='DONE',outcome=outcome))
    item=dict(key='000001',root=str(old),status='validated_complete',input_sha256='input',truth_sha256='truth',
        validated_sha256=digest(task/'validated.json'),output_sha256={},reconciled_sha256=digest(folder/'reconciled.json'))
    audit=dict(root=str(old),owner=owner,plan_sha256=digest(old/'PREPARED.json'),
        terminal_sha256=digest(old/'receipts/controller-terminal.json'),imports=[item],
        receipts={'000001':dict(accepted_sha256=digest(folder/'accepted.json'),reconciled_sha256=item['reconciled_sha256'])})
    write(new/'parent-audit.json',audit)
    monkeypatch.setattr(w,'validate',lambda *args:value)
    return new,old,dict(policy,predecessor_root=str(old),imports=[item],imported_cases=1),recovery


def test_import_revalidates_bound_terminal_result(tmp_path,monkeypatch):
    new,old,p,recovery=import_fixture(tmp_path,monkeypatch)
    assert recovery.prepare_recovery(new,p)=={'000001':'validated_complete'}
    assert read(new/'receipts/imports-validated.json')['predecessor_stopped']
    assert not (new/'receipts/000001').exists()  # No fabricated new submission.


def test_tampered_import_rejected_before_submission(tmp_path,monkeypatch):
    new,old,p,recovery=import_fixture(tmp_path,monkeypatch)
    (old/'results/000001/validated.json').write_text('{}')
    with pytest.raises(AssertionError):recovery.prepare_recovery(new,p)
    assert not (new/'receipts/imports-validated.json').exists()


def test_new_unbound_parent_intent_prevents_recovery(tmp_path,monkeypatch):
    new,old,p,recovery=import_fixture(tmp_path,monkeypatch)
    folder=old/'receipts/unbound';folder.mkdir();write(folder/'submit-intent.json',{})
    with pytest.raises(KeyError):recovery.prepare_recovery(new,p)
    assert not (new/'receipts/imports-validated.json').exists()


def test_output_validation_failure_keeps_its_classification(tmp_path,monkeypatch):
    root=base(tmp_path);folder=root/'receipts/000001';folder.mkdir()
    a=dict(key='000001',job_id='123',job_name='mine')
    write(folder/'terminal.json',dict(key='000001',job_id='123',status='output_validation_failure'))
    monkeypatch.setattr(c,'command',lambda *args:dict(code=0,stdout='123 yding4 EXIT mine',stderr=''))
    states,done=c.reconcile(root,{'123':a})
    assert states['123']=='EXIT' and done[0][1]['status']=='output_validation_failure'


@pytest.mark.parametrize('validation_fails',[False,True])
def test_actual_child_uses_preserved_basename_and_classifies_validation(tmp_path,monkeypatch,validation_fails):
    from clipp1d import cuda_api
    from clipp1d.io import SCHEMA_COLUMNS,read_tumor
    root=base(tmp_path)
    write(root/'PREPARED.json',dict(source_commit='base'),replace=True)
    task=root/'results/000001';(task/'input').mkdir(parents=True)
    data=('\t'.join(SCHEMA_COLUMNS)+'\n'+'m1\tregion1\t20\t80\t1\t0.8\t2\tseg1\tstate1\t1\t1\t1\n').encode()
    (task/'input/original.tsv').write_bytes(data)
    case=dict(key='000001',input_filename='original.tsv',input_sha256=hashlib.sha256(data).hexdigest(),
        tumor_id='original',sample_id='region1',retained_mutations=1,
        retained_ids_sha256=hashlib.sha256(json.dumps(['m1']).encode()).hexdigest(),truth_sha256='truth')
    write(root/'cases.json',[case])
    helper=root/'source/benchmarks/cohort_staging.py';helper.parent.mkdir(parents=True)
    helper.write_bytes((Path(__file__).resolve().parents[2]/'benchmarks/cohort_staging.py').read_bytes())
    monkeypatch.setattr(w,'plan',lambda root:read(root/'PREPARED.json'))
    monkeypatch.setattr(w,'accepted',lambda *args:None)
    calls=[]
    def fit(path,output,**kwargs):
        assert path==task/'input/original.tsv' and read_tumor(path).tumor_id=='original'
        calls.append(path)
        return __import__('types').SimpleNamespace(operation_metrics={})
    monkeypatch.setattr(cuda_api,'fit',fit)
    def validate(*args):
        if validation_fails:raise AssertionError('test output-ID mismatch')
        return dict(search_status='complete')
    monkeypatch.setattr(w,'validate',validate)
    code=w.child(root,'000001')
    assert len(calls)==1 and code==(21 if validation_fails else 0)
    if validation_fails:
        assert read(task/'validation-failure.json')['error']=='test output-ID mismatch'
    else:assert (task/'validated.json').exists()

"""One admitted GPU task; no retries and no multi-tumor worker shards."""
import csv
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
import zipfile
from common import accepted, digest, now, plan, read, verify_files, write


def validate(root, case, output, result=None):
    sys.path.insert(0, str(root/'source/benchmarks'))
    from compare_clipp2 import metrics, read_rows
    p = read(root/'PREPARED.json')
    run = read(output/'run.json')
    assert run['schema'] == 'clipp1d.cuda.run.v3' and run['status'] == 'success'
    source = run['provenance']
    assert source['source_sha256'] == p['source_sha256']
    assert source['input_sha256'] == case['input_sha256']
    assert source['backend'] == 'cuda' and source['dtype'] == 'float64'
    assert source['clonal_constraint'] is False and source['clonal_label_rule'] == 'nearest_to_one_l2_v1'
    assert source['policy'] == p['cuda_policy'] and source['max_major_cn'] == 4
    assert source['compiled_inference'] is True and source['cpu_numeric_fallback'] is False
    names = {'mutation_clusters.tsv','mutation_multiplicity.tsv','cluster_centers.tsv'}
    assert set(run['table_sha256']) == names
    assert {f.name for f in output.iterdir()} == names | {'run.json'}
    for name, sha in run['table_sha256'].items():
        assert digest(output/name) == sha
    rows = read_rows(output/'mutation_clusters.tsv')
    calls = read_rows(output/'mutation_multiplicity.tsv')
    ids = sorted(rows)
    assert len(ids) == case['retained_mutations'] and set(calls) == set(rows)
    assert hashlib.sha256(json.dumps(ids).encode()).hexdigest() == case['retained_ids_sha256']
    assert all(r['tumor_id'] == case['tumor_id'] and r['sample_id'] == case['sample_id'] for r in rows.values())
    with (output/'cluster_centers.tsv').open() as stream:
        centers = list(csv.DictReader(stream, delimiter='\t'))
    labels = {r['cluster_label'] for r in rows.values()}
    center = {r['cluster_label']: r for r in centers}
    assert len(centers) == len(labels) and set(center) == labels
    assert labels == set(map(str, range(len(labels))))
    for label, c in center.items():
        members = [row for row in rows.values() if row['cluster_label'] == label]
        assert int(c['cluster_size']) == len(members)
        assert all(float(r['refitted_ccf']) == float(c['refitted_ccf']) for r in members)
        assert c['designated_clonal'] == ('1' if label == '0' else '0')
    assert abs(float(center['0']['refitted_ccf'])-1) == min(abs(float(c['refitted_ccf'])-1) for c in centers)
    lineage = run['candidate_provenance']
    assert lineage['raw_qualified'] is True and lineage['refit_qualified'] is True
    assert lineage['candidate_family'] == 'complete_graph_path'
    assert lineage['graph_sha256'] == run['graph_sha256'] and lineage['raw_certificate'] == run['raw_diagnostics']
    records = run['search']
    complete = all(r.get('raw_status') == r.get('refit_status') == 'qualified' and r.get('search_complete',False) for r in records)
    assert run['search_status'] == ('complete' if complete else 'incomplete')
    qualified = [r for r in records if r.get('raw_status') == r.get('refit_status') == 'qualified']
    winner = min(qualified, key=lambda r:(r['score'],r['clusters'],r['lambda_value']))
    assert (run['selection_score'],len(centers),run['selected_lambda']) == (winner['score'],winner['clusters'],winner['lambda_value'])
    if result is not None:
        from clipp1d.cuda_api import _validate_result
        from clipp1d.io import read_tumor
        from cohort_staging import staged_input_path
        _validate_result(result, read_tumor(staged_input_path(output.parent, case)), records)
    truth_path = output.parent/'truth.tsv'
    assert digest(truth_path) == case['truth_sha256']
    truth = read_rows(truth_path)
    scored = {i:row for i,row in rows.items() if i in truth}
    assert set(rows)-set(truth) == set(case['truth_unmatched_retained'])
    assert len(scored)/len(rows) == case['truth_coverage']
    adapted = {i:dict(row,multiplicity_call=row['refitted_multiplicity_call']) for i,row in calls.items()}
    metric = metrics(scored, truth, adapted, 'refitted_ccf')
    metric.update(true_smf=sum(float(truth[i]['true_ccf']) < 1-1e-12 for i in scored)/len(scored),
                  estimated_smf=sum(row['cluster_label'] != '0' for row in scored.values())/len(scored),
                  full_retained_estimated_smf=sum(row['cluster_label'] != '0' for row in rows.values())/len(rows),
                  truth_matched=len(scored), truth_unmatched=len(rows)-len(scored),
                  true_k=len({truth[i]['true_cluster'] for i in scored}), full_retained_selected_k=len(centers),
                  ccf_estimator='final_refit', multiplicity_estimator='final_refit',
                  smf_definition='fraction outside designated closest-to-one public label 0; truth CCF < 1-1e-12',
                  search_status=run['search_status'])
    return dict(metrics=metric, output_sha256={name:digest(output/name) for name in names|{'run.json'}},
                source_sha256=source['source_sha256'], search_status=run['search_status'])


def child(root, key):
    p = plan(root)
    accepted(root,key)
    sys.path.insert(0,str(root/'source/src'))
    import torch
    from clipp1d.cuda_api import fit
    sys.path.insert(0,str(root/'source/benchmarks'))
    from cohort_staging import staged_input_path, verify_staged_input
    from clipp1d.cuda.policy import QualificationError
    case = next(c for c in read(root/'cases.json') if c['key'] == key)
    task = root/'results'/key
    try:
        verify_staged_input(task,case)
        result = fit(staged_input_path(task,case),task/'output',device='cuda:0',max_major_cn=4)
    except (QualificationError, MemoryError, torch.OutOfMemoryError) as error:
        write(task/'fit-failure.json',dict(error_type=type(error).__name__,error=str(error),
            category='resource_failure' if isinstance(error,(MemoryError,torch.OutOfMemoryError)) else 'scientific_failure',
            traceback=traceback.format_exc(), utc=now()))
        return 20
    try:
        validation = validate(root,case,task/'output',result)
    except (AssertionError, ValueError, KeyError) as error:
        write(task/'validation-failure.json',dict(error_type=type(error).__name__,error=str(error),
            traceback=traceback.format_exc(),utc=now()))
        return 21
    write(task/'validated.json',dict(validation,operation_metrics=result.operation_metrics,utc=now(),
          source_commit=p['source_commit'],input_sha256=case['input_sha256'],truth_sha256=case['truth_sha256']))
    return 0


def worker(root,key):
    p = plan(root)
    assert sys.executable == p['python']
    a, receipt = accepted(root,key)  # Before claim/finalizer: foreign jobs cannot publish terminals.
    write(receipt/'execution.json',dict(job_id=a['job_id'],pid=os.getpid(),host=os.uname().nodename,utc=now()))
    start=time.monotonic()
    terminal=dict(key=key,job_id=a['job_id'],status='setup_failure',utc_started=now())
    try:
        verify_files(root)
        freeze='\n'.join(sorted(subprocess.check_output([sys.executable,'-m','pip','freeze','--disable-pip-version-check'],text=True).splitlines()))+'\n'
        assert hashlib.sha256(freeze.encode()).hexdigest() == p['environment_sha256']
        assert digest(p['compiler']['path']) == p['compiler']['sha256']
        env=dict(os.environ,PYTHONPATH=str(root/'source/src'),PYTHONDONTWRITEBYTECODE='1',
            CC=p['compiler']['path'],OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
            NUMEXPR_NUM_THREADS='1',TORCHINDUCTOR_COMPILE_THREADS='1',
            TORCHINDUCTOR_CACHE_DIR=str(root/'results/compiler-cache/inductor'),
            TRITON_CACHE_DIR=str(root/'results/compiler-cache/triton'))
        probe="""import torch,json,clipp1d
from clipp1d.api import source_provenance
assert torch.cuda.is_available() and torch.cuda.device_count()==1
assert 'L40' in torch.cuda.get_device_name(0)
assert torch.ones(4,device='cuda',dtype=torch.float64).sum().item()==4
print(json.dumps(dict(gpu=torch.cuda.get_device_name(0),free_total=torch.cuda.mem_get_info(),source=source_provenance(),package=clipp1d.__file__)))"""
        runtime=json.loads(subprocess.check_output([sys.executable,'-B','-c',probe],env=env,text=True,timeout=120))
        assert runtime['source']['source_sha256']==p['source_sha256']
        assert Path(runtime['package']).resolve().parent==root/'source/src/clipp1d'
        write(receipt/'startup.json',dict(runtime=runtime,job_id=a['job_id'],environment_sha256=p['environment_sha256'],utc=now()))
        task=root/'results'/key
        task.mkdir()
        if key=='qualification':
            argv=[sys.executable,'-B',str(root/'source/benchmarks/qualify_cuda.py'),'--out',str(task/'qualification.json'),
                  '--path-grid','default','--resource-n','256','--timeout-seconds','2700']
            timeout=2850
        else:
            case=next(c for c in read(root/'cases.json') if c['key']==key)
            sys.path.insert(0,str(root/'source/src'))
            sys.path.insert(0,str(root/'source/benchmarks'))
            from cohort_staging import stage_case_input
            with zipfile.ZipFile(root/'payload.zip') as bundle:
                stage_case_input(task,case,bundle)
                for prefix in ('truth',):
                    data=bundle.read(case[prefix+'_member'])
                    assert hashlib.sha256(data).hexdigest()==case[prefix+'_sha256']
                    with (task/(prefix+'.tsv')).open('xb') as out:
                        out.write(data)
            argv=[sys.executable,'-B',str(root/'worker.py'),'child',str(root),key]
            timeout=case['wall_minutes']*60-180
        write(receipt/'command.json',dict(argv=argv,timeout_seconds=timeout,environment_overrides={k:env[k] for k in env if k not in os.environ or env[k]!=os.environ[k]}))
        terminal['status']='execution_failure'
        with (root/'case-logs'/f'{key}.out').open('xb') as out,(root/'case-logs'/f'{key}.err').open('xb') as err:
            proc=subprocess.Popen(argv,env=env,cwd=root/'source',stdout=out,stderr=err,start_new_session=True)
            try:
                code=proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGTERM)
                try:
                    proc.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid,signal.SIGKILL)
                    proc.wait()
                terminal['status']='resource_timeout'
                code=None
        terminal['returncode']=code
        if key=='qualification':
            q=read(task/'qualification.json')
            assert code==0 and q['status']=='passed'
            terminal.update(status='qualified',receipt_sha256=digest(task/'qualification.json'))
        elif code==0:
            v=read(task/'validated.json')
            # Independent serialized readback, with no CUDA fit in this parent.
            assert validate(root,case,task/'output') == {k:v[k] for k in ('metrics','output_sha256','source_sha256','search_status')}
            terminal.update(status='validated_'+v['search_status'],validated_sha256=digest(task/'validated.json'))
        elif code==20:
            failure=read(task/'fit-failure.json')
            terminal.update(status=failure['category'],failure_sha256=digest(task/'fit-failure.json'))
        elif code==21:
            failure=read(task/'validation-failure.json')
            terminal.update(status='output_validation_failure',failure_sha256=digest(task/'validation-failure.json'),
                            error_type=failure['error_type'],error=failure['error'],traceback=failure['traceback'])
        elif terminal['status']!='resource_timeout':
            terminal['status']='execution_failure'
            error_log=root/'case-logs'/f'{key}.err'
            with error_log.open('rb') as stream:
                stream.seek(max(0,error_log.stat().st_size-6000))
                terminal['stderr_tail']=stream.read().decode(errors='replace')
            terminal['stderr_sha256']=digest(error_log)
    except BaseException as error:
        terminal.update(error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        terminal.update(utc_finished=now(),elapsed_seconds=time.monotonic()-start)
        write(receipt/'terminal.json',terminal)
    return 0 if terminal['status'] in ('qualified','validated_complete','validated_incomplete','scientific_failure','resource_failure','resource_timeout') else 1


if __name__=='__main__':
    action,root,key=sys.argv[1:]
    sys.exit((child if action=='child' else worker)(Path(root),key))
